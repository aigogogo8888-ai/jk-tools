# JK Tools - LobsterAI 技能集合

> 🦞 與 LobsterAI 共同開發的工具與技能集

## 📁 項目結構

```
jk-tools/
├── crypto-tracker/     # 加密貨幣追蹤系統
├── calendar-tools/     # 日曆工具集
└── jk-design/          # JK 助理形象設計
```

## 🚀 技能介紹

### 1. Crypto Tracker - 加密貨幣追蹤系統

功能豐富的加密貨幣監控與分析工具：

- **即時價格追蹤**：支援 BTC、ETH、SOL 等主流幣種
- **技術指標分析**：RSI、MACD、布林帶、移動平均線
- **價格警報系統**：可設定價格觸發條件
- **自動報告生成**：定時產生市場分析報告
- **飛書整合**：自動發送報告到飛書群組

**主要檔案：**
- `main.py` - 主程式入口
- `data_fetcher.py` - 數據獲取模組
- `indicators.py` - 技術指標計算
- `alert_system.py` - 警報系統

**使用方法：**
```bash
cd crypto-tracker
pip install -r requirements.txt
python main.py --report  # 生成報告
python main.py --alert   # 啟動警報監控
```

---

### 2. Calendar Tools - 日曆工具集

投資行事曆管理與同步工具：

- **Google 日曆整合**：匯入投資行程與財報日期
- **CSV 行程匯入**：批量導入投資計畫
- **自動提醒設定**：重要事件自動通知

**主要檔案：**
- `investment_schedule.py` - 投資行程管理
- `google_calendar_import.py` - Google 日曆匯入
- `sample_schedule.csv` - 範例行程檔案

---

### 3. JK Design - JK 助理形象設計

LobsterAI 助理 "JK" 的視覺形象設計：

- **形象海報**：專業助理視覺設計
- **設計理念**：韓劇金秘書美學風格

**檔案：**
- `JK_assistant_portrait.png` - JK 助理形象海報
- `design_philosophy.md` - 設計理念說明

---

## 🤝 共同開發

歡迎提交 Issue 和 Pull Request 來共同加強這些工具！

### 貢獻指南

1. Fork 此倉庫
2. 創建您的功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交您的更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 開啟一個 Pull Request

---

## 📜 授權

MIT License - 詳見 [LICENSE](LICENSE) 檔案

---

## 🙏 致謝

- [LobsterAI](https://www.lobsterai.com/) - 強大的 AI 助理平台
- 所有貢獻者與使用者

---

> 💡 **提示**：這些工具是與 LobsterAI 共同開發的，旨在提升工作效率與投資決策品質。
