"""
數據抓取模組 - 從 CoinGecko API 獲取加密貨幣數據
"""

import requests
import time
import json
from datetime import datetime
from typing import Dict, List, Optional
from config import COINGECKO_API_URL, CRYPTO_SYMBOLS, REQUEST_TIMEOUT, API_RATE_LIMIT


class CryptoDataFetcher:
    """加密貨幣數據抓取器"""

    def __init__(self):
        self.base_url = COINGECKO_API_URL
        self.last_request_time = 0

    def _rate_limit(self):
        """確保符合 API 速率限制"""
        elapsed = time.time() - self.last_request_time
        if elapsed < API_RATE_LIMIT:
            time.sleep(API_RATE_LIMIT - elapsed)
        self.last_request_time = time.time()

    def get_current_prices(self) -> Dict[str, Dict]:
        """
        獲取當前價格數據

        Returns:
            Dict: 各幣種當前價格數據
        """
        self._rate_limit()

        ids = ",".join(CRYPTO_SYMBOLS.keys())
        url = f"{self.base_url}/simple/price"
        params = {
            "ids": ids,
            "vs_currencies": "usd",
            "include_24hr_change": "true",
            "include_24hr_vol": "true",
            "include_market_cap": "true",
            "include_last_updated_at": "true"
        }

        try:
            response = requests.get(url, params=params, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            data = response.json()

            # 格式化數據
            result = {}
            for coin_id, symbol in CRYPTO_SYMBOLS.items():
                if coin_id in data:
                    result[symbol] = {
                        "price": data[coin_id].get("usd", 0),
                        "change_24h": data[coin_id].get("usd_24h_change", 0),
                        "volume_24h": data[coin_id].get("usd_24h_vol", 0),
                        "market_cap": data[coin_id].get("usd_market_cap", 0),
                        "last_updated": datetime.fromtimestamp(
                            data[coin_id].get("last_updated_at", 0)
                        ).strftime("%Y-%m-%d %H:%M:%S")
                    }

            return result

        except requests.exceptions.RequestException as e:
            print(f"獲取價格數據失敗: {e}")
            return {}

    def get_historical_prices(self, coin_id: str, days: int = 30) -> List[Dict]:
        """
        獲取歷史價格數據（用於技術指標計算）

        Args:
            coin_id: CoinGecko 幣種 ID
            days: 獲取天數

        Returns:
            List[Dict]: 歷史價格列表
        """
        self._rate_limit()

        url = f"{self.base_url}/coins/{coin_id}/market_chart"
        params = {
            "vs_currency": "usd",
            "days": days,
            "interval": "daily"
        }

        try:
            response = requests.get(url, params=params, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            data = response.json()

            # 格式化價格數據
            prices = []
            if "prices" in data:
                for timestamp, price in data["prices"]:
                    prices.append({
                        "timestamp": datetime.fromtimestamp(timestamp / 1000).strftime("%Y-%m-%d"),
                        "price": price
                    })

            return prices

        except requests.exceptions.RequestException as e:
            print(f"獲取歷史數據失敗 ({coin_id}): {e}")
            return []

    def get_coin_info(self, coin_id: str) -> Dict:
        """
        獲取幣種詳細資訊

        Args:
            coin_id: CoinGecko 幣種 ID

        Returns:
            Dict: 幣種詳細資訊
        """
        self._rate_limit()

        url = f"{self.base_url}/coins/{coin_id}"
        params = {
            "localization": "false",
            "tickers": "false",
            "market_data": "true",
            "community_data": "false",
            "developer_data": "false"
        }

        try:
            response = requests.get(url, params=params, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            data = response.json()

            market_data = data.get("market_data", {})

            return {
                "name": data.get("name", ""),
                "symbol": data.get("symbol", "").upper(),
                "current_price": market_data.get("current_price", {}).get("usd", 0),
                "high_24h": market_data.get("high_24h", {}).get("usd", 0),
                "low_24h": market_data.get("low_24h", {}).get("usd", 0),
                "price_change_24h": market_data.get("price_change_24h", 0),
                "price_change_24h_percent": market_data.get("price_change_percentage_24h", 0),
                "price_change_7d_percent": market_data.get("price_change_percentage_7d", 0),
                "price_change_30d_percent": market_data.get("price_change_percentage_30d", 0),
                "market_cap": market_data.get("market_cap", {}).get("usd", 0),
                "total_volume": market_data.get("total_volume", {}).get("usd", 0),
                "circulating_supply": market_data.get("circulating_supply", 0),
                "total_supply": market_data.get("total_supply", 0),
                "max_supply": market_data.get("max_supply", 0),
                "ath": market_data.get("ath", {}).get("usd", 0),  # 歷史最高價
                "ath_change_percent": market_data.get("ath_change_percentage", {}).get("usd", 0),
                "atl": market_data.get("atl", {}).get("usd", 0),  # 歷史最低價
            }

        except requests.exceptions.RequestException as e:
            print(f"獲取幣種資訊失敗 ({coin_id}): {e}")
            return {}

    def get_market_overview(self) -> Dict:
        """
        獲取市場整體概覽

        Returns:
            Dict: 市場概覽數據
        """
        self._rate_limit()

        url = f"{self.base_url}/global"

        try:
            response = requests.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            data = response.json().get("data", {})

            return {
                "active_cryptocurrencies": data.get("active_cryptocurrencies", 0),
                "total_market_cap_usd": data.get("total_market_cap", {}).get("usd", 0),
                "total_volume_24h_usd": data.get("total_volume", {}).get("usd", 0),
                "market_cap_change_24h": data.get("market_cap_change_percentage_24h_usd", 0),
                "btc_dominance": data.get("market_cap_percentage", {}).get("btc", 0),
                "eth_dominance": data.get("market_cap_percentage", {}).get("eth", 0),
            }

        except requests.exceptions.RequestException as e:
            print(f"獲取市場概覽失敗: {e}")
            return {}


if __name__ == "__main__":
    # 測試數據抓取
    fetcher = CryptoDataFetcher()

    print("=" * 60)
    print("測試數據抓取模組")
    print("=" * 60)

    # 測試 1: 獲取當前價格
    print("\n1. 當前價格數據:")
    prices = fetcher.get_current_prices()
    for symbol, data in prices.items():
        print(f"  {symbol}: ${data['price']:,.2f} (24h: {data['change_24h']:+.2f}%)")

    # 測試 2: 獲取市場概覽
    print("\n2. 市場概覽:")
    overview = fetcher.get_market_overview()
    print(f"  總市值: ${overview.get('total_market_cap_usd', 0):,.0f}")
    print(f"  BTC 市佔率: {overview.get('btc_dominance', 0):.2f}%")

    # 測試 3: 獲取比特幣詳細資訊
    print("\n3. 比特幣詳細資訊:")
    btc_info = fetcher.get_coin_info("bitcoin")
    print(f"  名稱: {btc_info.get('name')}")
    print(f"  當前價格: ${btc_info.get('current_price', 0):,.2f}")
    print(f"  24h 最高: ${btc_info.get('high_24h', 0):,.2f}")
    print(f"  24h 最低: ${btc_info.get('low_24h', 0):,.2f}")
    print(f"  歷史最高: ${btc_info.get('ath', 0):,.2f}")
