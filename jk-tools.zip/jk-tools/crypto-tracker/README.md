# 比特幣追蹤系統 (Crypto Tracker)

一個功能完整的加密貨幣市場追蹤與分析系統，支援即時價格獲取、技術指標計算、價格異動警報等功能。

## 功能特性

### 1. 即時價格追蹤
- 支援多幣種同時監控 (BTC, ETH, BNB, SOL, XRP)
- 24小時價格變化追蹤
- 市值與交易量數據

### 2. 技術指標分析
- **移動平均線**: SMA (7日/30日), EMA
- **RSI**: 相對強弱指標 (判斷超買/超賣)
- **MACD**: 異同移動平均線 (趨勢判斷)
- **布林帶**: 價格波動區間分析
- **趨勢分析**: 自動判斷看漲/看跌/中性
- **交易信號**: 生成買入/賣出/持有建議

### 3. 價格異動警報
- 24小時漲跌超過閾值警報
- 短期價格波動監控
- 自定義價格閾值警報
- 警報歷史記錄保存

### 4. 數據存儲
- CSV 格式歷史價格記錄
- 警報日誌追蹤
- 自動數據清理 (保留最近100條)

## 安裝

```bash
# 克隆或下載專案
cd crypto-tracker

# 安裝依賴
pip install -r requirements.txt
```

## 使用方法

### 基本使用

```bash
# 生成完整報告
python main.py

# 只分析特定幣種
python main.py --symbol BTC

# 只顯示技術指標
python main.py --indicator

# 只檢查價格警報
python main.py --alert
```

### 配置說明

編輯 `config.py` 文件來自定義系統：

```python
# 添加要追蹤的幣種
CRYPTO_SYMBOLS = {
    "bitcoin": "BTC",
    "ethereum": "ETH",
    # 添加更多...
}

# 調整技術指標參數
INDICATOR_PARAMS = {
    "sma_short": 7,      # 短期均線天數
    "sma_long": 30,      # 長期均線天數
    "rsi_period": 14,    # RSI 計算週期
}

# 設置警報閾值
ALERT_THRESHOLDS = {
    "price_change_24h": 5.0,    # 24小時變化超過 5% 警報
    "price_change_1h": 3.0      # 1小時變化超過 3% 警報
}
```

## 專案結構

```
crypto-tracker/
├── main.py              # 主程式入口
├── config.py            # 配置文件
├── data_fetcher.py      # 數據抓取模組
├── indicators.py        # 技術指標計算
├── alert_system.py      # 警報系統
├── requirements.txt     # 依賴列表
├── README.md            # 說明文件
└── data/                # 數據存儲目錄
    ├── price_history.csv
    └── alerts.log
```

## 技術指標說明

### RSI (相對強弱指標)
- RSI > 70: 超買區域，可能回調
- RSI < 30: 超賣區域，可能反彈
- RSI 30-70: 正常區間

### MACD
- MACD > Signal: 看漲信號
- MACD < Signal: 看跌信號
- Histogram: 兩者差值，顯示動能強度

### 布林帶
- 價格觸及上軌: 可能超買
- 價格觸及下軌: 可能超賣
- 價格在中軌: 趨勢平穩

## API 來源

使用 [CoinGecko API](https://www.coingecko.com/api) (免費版)：
- 無需 API Key
- 速率限制: 每秒 1 個請求
- 數據更新頻率: 約 1-5 分鐘

## 定時任務整合

可以將此系統設置為定時任務，定期自動執行：

```bash
# 每天早上 9 點執行並發送報告到釘釘
# 在 LobsterAI 中設置定時任務：
# - 時間: 每天 9:00
# - 命令: python C:\Users\User\lobsterai\project\crypto-tracker\main.py --report
```

## 免責聲明

本系統僅供學習和研究使用，不構成任何投資建議。加密貨幣市場風險極高，請謹慎投資。

## License

MIT License
