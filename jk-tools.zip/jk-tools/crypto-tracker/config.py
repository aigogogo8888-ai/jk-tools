"""
比特幣追蹤系統 - 配置文件
"""

# API 配置
COINGECKO_API_URL = "https://api.coingecko.com/api/v3"

# 追蹤的加密貨幣 (CoinGecko ID: 幣種代碼)
CRYPTO_SYMBOLS = {
    "bitcoin": "BTC",
    "ethereum": "ETH",
    "binancecoin": "BNB",
    "solana": "SOL",
    "ripple": "XRP"
}

# 技術指標參數
INDICATOR_PARAMS = {
    "sma_short": 7,      # 短期均線 (7日)
    "sma_long": 30,      # 長期均線 (30日)
    "rsi_period": 14,    # RSI 計算週期
    "macd_fast": 12,     # MACD 快線
    "macd_slow": 26,     # MACD 慢線
    "macd_signal": 9     # MACD 信號線
}

# 價格警報閾值 (百分比)
ALERT_THRESHOLDS = {
    "price_change_24h": 5.0,    # 24小時漲跌超過 5% 警報
    "price_change_1h": 3.0      # 1小時漲跌超過 3% 警報
}

# 數據存儲
DATA_DIR = "data"
HISTORY_FILE = "data/price_history.csv"
ALERT_LOG_FILE = "data/alerts.log"

# 請求配置
REQUEST_TIMEOUT = 30
API_RATE_LIMIT = 1.0  # 每秒最多 1 個請求 (CoinGecko 免費版限制)
