"""
價格異動警報系統 - 監控價格變化並生成警報
"""

import os
import json
import csv
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from config import ALERT_THRESHOLDS, DATA_DIR, HISTORY_FILE, ALERT_LOG_FILE


@dataclass
class PriceAlert:
    """價格警報數據類"""
    timestamp: str
    symbol: str
    alert_type: str          # price_change_24h, price_change_1h, threshold_cross
    severity: str            # info, warning, critical
    message: str
    current_price: float
    change_percent: float
    threshold: float


class AlertSystem:
    """價格異動警報系統"""

    def __init__(self):
        self.alerts: List[PriceAlert] = []
        self.price_history: Dict[str, List[Dict]] = {}
        self._ensure_data_dir()
        self._load_history()

    def _ensure_data_dir(self):
        """確保數據目錄存在"""
        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR)

    def _load_history(self):
        """加載歷史價格數據"""
        if os.path.exists(HISTORY_FILE):
            try:
                with open(HISTORY_FILE, 'r', newline='', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        symbol = row['symbol']
                        if symbol not in self.price_history:
                            self.price_history[symbol] = []
                        self.price_history[symbol].append({
                            'timestamp': row['timestamp'],
                            'price': float(row['price']),
                            'change_24h': float(row.get('change_24h', 0))
                        })
            except Exception as e:
                print(f"加載歷史數據失敗: {e}")

    def save_price_data(self, symbol: str, price: float, change_24h: float = 0):
        """
        保存價格數據到歷史記錄

        Args:
            symbol: 幣種代碼
            price: 當前價格
            change_24h: 24小時變化百分比
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 添加到內存
        if symbol not in self.price_history:
            self.price_history[symbol] = []

        self.price_history[symbol].append({
            'timestamp': timestamp,
            'price': price,
            'change_24h': change_24h
        })

        # 限制歷史數據長度（保留最近 100 條）
        if len(self.price_history[symbol]) > 100:
            self.price_history[symbol] = self.price_history[symbol][-100:]

        # 寫入 CSV
        file_exists = os.path.exists(HISTORY_FILE)
        with open(HISTORY_FILE, 'a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(['timestamp', 'symbol', 'price', 'change_24h'])
            writer.writerow([timestamp, symbol, price, change_24h])

    def check_price_change_alerts(self, symbol: str, current_data: Dict) -> List[PriceAlert]:
        """
        檢查價格變化警報

        Args:
            symbol: 幣種代碼
            current_data: 當前價格數據

        Returns:
            List[PriceAlert]: 觸發的警報列表
        """
        alerts = []
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        price = current_data.get('price', 0)
        change_24h = current_data.get('change_24h', 0)

        # 保存價格數據
        self.save_price_data(symbol, price, change_24h)

        # 檢查 24 小時變化
        threshold_24h = ALERT_THRESHOLDS['price_change_24h']
        if abs(change_24h) >= threshold_24h:
            severity = "critical" if abs(change_24h) >= threshold_24h * 2 else "warning"
            direction = "上漲" if change_24h > 0 else "下跌"

            alert = PriceAlert(
                timestamp=timestamp,
                symbol=symbol,
                alert_type="price_change_24h",
                severity=severity,
                message=f"{symbol} 24小時內{direction} {abs(change_24h):.2f}%",
                current_price=price,
                change_percent=change_24h,
                threshold=threshold_24h
            )
            alerts.append(alert)

        # 檢查短期價格波動（與上次記錄比較）
        if symbol in self.price_history and len(self.price_history[symbol]) >= 2:
            prev_price = self.price_history[symbol][-2]['price']
            if prev_price > 0:
                short_change = ((price - prev_price) / prev_price) * 100
                threshold_1h = ALERT_THRESHOLDS['price_change_1h']

                if abs(short_change) >= threshold_1h:
                    severity = "warning" if abs(short_change) < threshold_1h * 1.5 else "critical"
                    direction = "暴漲" if short_change > 0 else "暴跌"

                    alert = PriceAlert(
                        timestamp=timestamp,
                        symbol=symbol,
                        alert_type="price_change_1h",
                        severity=severity,
                        message=f"{symbol} 短期內{direction} {abs(short_change):.2f}%",
                        current_price=price,
                        change_percent=short_change,
                        threshold=threshold_1h
                    )
                    alerts.append(alert)

        return alerts

    def check_threshold_alerts(self, symbol: str, current_price: float,
                                upper_threshold: Optional[float] = None,
                                lower_threshold: Optional[float] = None) -> List[PriceAlert]:
        """
        檢查價格閾值警報

        Args:
            symbol: 幣種代碼
            current_price: 當前價格
            upper_threshold: 上限價格
            lower_threshold: 下限價格

        Returns:
            List[PriceAlert]: 觸發的警報列表
        """
        alerts = []
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if upper_threshold and current_price >= upper_threshold:
            alert = PriceAlert(
                timestamp=timestamp,
                symbol=symbol,
                alert_type="threshold_cross",
                severity="info",
                message=f"{symbol} 突破上限 ${upper_threshold:,.2f}",
                current_price=current_price,
                change_percent=0,
                threshold=upper_threshold
            )
            alerts.append(alert)

        if lower_threshold and current_price <= lower_threshold:
            alert = PriceAlert(
                timestamp=timestamp,
                symbol=symbol,
                alert_type="threshold_cross",
                severity="info",
                message=f"{symbol} 跌破下限 ${lower_threshold:,.2f}",
                current_price=current_price,
                change_percent=0,
                threshold=lower_threshold
            )
            alerts.append(alert)

        return alerts

    def add_alert(self, alert: PriceAlert):
        """添加警報到列表"""
        self.alerts.append(alert)

    def save_alerts(self):
        """保存警報到日誌文件"""
        if not self.alerts:
            return

        file_exists = os.path.exists(ALERT_LOG_FILE)
        with open(ALERT_LOG_FILE, 'a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(['timestamp', 'symbol', 'alert_type', 'severity',
                               'message', 'current_price', 'change_percent', 'threshold'])

            for alert in self.alerts:
                writer.writerow([
                    alert.timestamp,
                    alert.symbol,
                    alert.alert_type,
                    alert.severity,
                    alert.message,
                    alert.current_price,
                    alert.change_percent,
                    alert.threshold
                ])

    def get_recent_alerts(self, hours: int = 24) -> List[PriceAlert]:
        """
        獲取最近 N 小時的警報

        Args:
            hours: 小時數

        Returns:
            List[PriceAlert]: 警報列表
        """
        from datetime import timedelta

        cutoff_time = datetime.now() - timedelta(hours=hours)
        recent_alerts = []

        for alert in self.alerts:
            alert_time = datetime.strptime(alert.timestamp, "%Y-%m-%d %H:%M:%S")
            if alert_time >= cutoff_time:
                recent_alerts.append(alert)

        return recent_alerts

    def format_alert(self, alert: PriceAlert) -> str:
        """
        格式化警報為可讀字符串

        Args:
            alert: 警報對象

        Returns:
            str: 格式化後的字符串
        """
        severity_icons = {
            "info": "ℹ️",
            "warning": "⚠️",
            "critical": "🚨"
        }

        icon = severity_icons.get(alert.severity, "ℹ️")

        lines = [
            f"{icon} [{alert.timestamp}] {alert.symbol}",
            f"   類型: {alert.alert_type}",
            f"   嚴重程度: {alert.severity.upper()}",
            f"   消息: {alert.message}",
            f"   當前價格: ${alert.current_price:,.2f}",
            f"   變化: {alert.change_percent:+.2f}%",
            "-" * 50
        ]

        return "\n".join(lines)

    def generate_alert_summary(self) -> str:
        """
        生成警報摘要報告

        Returns:
            str: 摘要報告
        """
        if not self.alerts:
            return "✅ 沒有觸發任何警報"

        critical_count = sum(1 for a in self.alerts if a.severity == "critical")
        warning_count = sum(1 for a in self.alerts if a.severity == "warning")
        info_count = sum(1 for a in self.alerts if a.severity == "info")

        lines = [
            "\n" + "=" * 50,
            "警報摘要報告",
            "=" * 50,
            f"總警報數: {len(self.alerts)}",
            f"  🚨 嚴重 (Critical): {critical_count}",
            f"  ⚠️ 警告 (Warning): {warning_count}",
            f"  ℹ️ 資訊 (Info): {info_count}",
            "",
            "詳細警報列表:",
            "-" * 50
        ]

        for alert in self.alerts:
            lines.append(self.format_alert(alert))

        lines.append("=" * 50)

        return "\n".join(lines)

    def clear_alerts(self):
        """清空當前警報列表"""
        self.alerts = []


if __name__ == "__main__":
    # 測試警報系統
    print("測試警報系統")
    print("=" * 50)

    alert_system = AlertSystem()

    # 模擬價格數據
    test_data = {
        'BTC': {'price': 85000, 'change_24h': 6.5},   # 觸發 24h 警報
        'ETH': {'price': 4500, 'change_24h': 2.1},    # 正常
        'SOL': {'price': 180, 'change_24h': -4.2},    # 正常
    }

    # 檢查警報
    for symbol, data in test_data.items():
        alerts = alert_system.check_price_change_alerts(symbol, data)
        for alert in alerts:
            alert_system.add_alert(alert)

    # 檢查閾值警報
    btc_alerts = alert_system.check_threshold_alerts('BTC', 85000,
                                                      upper_threshold=80000)
    for alert in btc_alerts:
        alert_system.add_alert(alert)

    # 輸出結果
    print(alert_system.generate_alert_summary())
