"""
技術指標計算模組 - 計算各種技術分析指標
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from config import INDICATOR_PARAMS


@dataclass
class IndicatorResult:
    """指標計算結果"""
    symbol: str
    current_price: float
    sma_short: Optional[float] = None
    sma_long: Optional[float] = None
    ema_short: Optional[float] = None
    ema_long: Optional[float] = None
    rsi: Optional[float] = None
    macd: Optional[float] = None
    macd_signal: Optional[float] = None
    macd_histogram: Optional[float] = None
    bollinger_upper: Optional[float] = None
    bollinger_lower: Optional[float] = None
    trend: str = "neutral"  # bullish, bearish, neutral
    signal: str = "hold"    # buy, sell, hold


class TechnicalIndicators:
    """技術指標計算器"""

    @staticmethod
    def calculate_sma(prices: List[float], period: int) -> Optional[float]:
        """
        計算簡單移動平均線 (SMA)

        Args:
            prices: 價格列表
            period: 計算週期

        Returns:
            float: SMA 值，數據不足時返回 None
        """
        if len(prices) < period:
            return None
        return sum(prices[-period:]) / period

    @staticmethod
    def calculate_ema(prices: List[float], period: int) -> Optional[float]:
        """
        計算指數移動平均線 (EMA)

        Args:
            prices: 價格列表
            period: 計算週期

        Returns:
            float: EMA 值
        """
        if len(prices) < period:
            return None

        # 使用 pandas 計算 EMA
        series = pd.Series(prices)
        ema = series.ewm(span=period, adjust=False).mean()
        return ema.iloc[-1]

    @staticmethod
    def calculate_rsi(prices: List[float], period: int = 14) -> Optional[float]:
        """
        計算相對強弱指標 (RSI)

        RSI > 70: 超買 (可能回調)
        RSI < 30: 超賣 (可能反彈)
        RSI 30-70: 正常區間

        Args:
            prices: 價格列表
            period: 計算週期 (預設 14)

        Returns:
            float: RSI 值 (0-100)
        """
        if len(prices) < period + 1:
            return None

        # 計算價格變化
        deltas = np.diff(prices)

        # 分離漲跌
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)

        # 計算平均漲跌
        avg_gain = np.mean(gains[:period])
        avg_loss = np.mean(losses[:period])

        # 使用平滑移動平均
        for i in range(period, len(gains)):
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period

        if avg_loss == 0:
            return 100.0

        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))

        return rsi

    @staticmethod
    def calculate_macd(prices: List[float], fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """
        計算 MACD 指標

        MACD > Signal: 看漲信號
        MACD < Signal: 看跌信號
        Histogram: MACD 與 Signal 的差值

        Args:
            prices: 價格列表
            fast: 快線週期
            slow: 慢線週期
            signal: 信號線週期

        Returns:
            Tuple: (MACD值, Signal值, Histogram值)
        """
        if len(prices) < slow + signal:
            return None, None, None

        series = pd.Series(prices)

        # 計算 EMA
        ema_fast = series.ewm(span=fast, adjust=False).mean()
        ema_slow = series.ewm(span=slow, adjust=False).mean()

        # MACD 線
        macd_line = ema_fast - ema_slow

        # Signal 線
        signal_line = macd_line.ewm(span=signal, adjust=False).mean()

        # Histogram
        histogram = macd_line - signal_line

        return (
            macd_line.iloc[-1],
            signal_line.iloc[-1],
            histogram.iloc[-1]
        )

    @staticmethod
    def calculate_bollinger_bands(prices: List[float], period: int = 20, std_dev: int = 2) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """
        計算布林帶 (Bollinger Bands)

        價格觸及上軌: 可能超買
        價格觸及下軌: 可能超賣
        價格在中軌: 趨勢平穩

        Args:
            prices: 價格列表
            period: 計算週期
            std_dev: 標準差倍數

        Returns:
            Tuple: (上軌, 中軌, 下軌)
        """
        if len(prices) < period:
            return None, None, None

        recent_prices = prices[-period:]
        sma = np.mean(recent_prices)
        std = np.std(recent_prices)

        upper_band = sma + (std * std_dev)
        lower_band = sma - (std * std_dev)

        return upper_band, sma, lower_band

    @staticmethod
    def analyze_trend(indicators: IndicatorResult) -> str:
        """
        分析趨勢方向

        Args:
            indicators: 指標結果

        Returns:
            str: 趨勢方向 (bullish/bearish/neutral)
        """
        bullish_signals = 0
        bearish_signals = 0

        # 均線判斷
        if indicators.sma_short and indicators.sma_long:
            if indicators.sma_short > indicators.sma_long:
                bullish_signals += 1
            else:
                bearish_signals += 1

        # RSI 判斷
        if indicators.rsi:
            if indicators.rsi > 50:
                bullish_signals += 1
            else:
                bearish_signals += 1

        # MACD 判斷
        if indicators.macd_histogram:
            if indicators.macd_histogram > 0:
                bullish_signals += 1
            else:
                bearish_signals += 1

        # 綜合判斷
        if bullish_signals > bearish_signals:
            return "bullish"
        elif bearish_signals > bullish_signals:
            return "bearish"
        return "neutral"

    @staticmethod
    def generate_signal(indicators: IndicatorResult) -> str:
        """
        生成交易信號

        Args:
            indicators: 指標結果

        Returns:
            str: 交易信號 (buy/sell/hold)
        """
        buy_signals = 0
        sell_signals = 0

        # RSI 信號
        if indicators.rsi:
            if indicators.rsi < 30:
                buy_signals += 2  # 超賣，強烈買入信號
            elif indicators.rsi > 70:
                sell_signals += 2  # 超買，強烈賣出信號

        # MACD 信號
        if indicators.macd_histogram:
            if indicators.macd_histogram > 0 and indicators.macd_histogram > (indicators.macd or 0) * 0.01:
                buy_signals += 1
            elif indicators.macd_histogram < 0:
                sell_signals += 1

        # 均線交叉信號
        if indicators.sma_short and indicators.sma_long:
            if indicators.sma_short > indicators.sma_long * 1.02:  # 短期均線高於長期 2%
                buy_signals += 1
            elif indicators.sma_short < indicators.sma_long * 0.98:  # 短期均線低於長期 2%
                sell_signals += 1

        # 布林帶信號
        if indicators.bollinger_upper and indicators.bollinger_lower:
            if indicators.current_price > indicators.bollinger_upper * 0.98:
                sell_signals += 1
            elif indicators.current_price < indicators.bollinger_lower * 1.02:
                buy_signals += 1

        # 綜合判斷
        if buy_signals >= 2 and buy_signals > sell_signals:
            return "buy"
        elif sell_signals >= 2 and sell_signals > buy_signals:
            return "sell"
        return "hold"

    def calculate_all(self, symbol: str, prices: List[float]) -> IndicatorResult:
        """
        計算所有技術指標

        Args:
            symbol: 幣種代碼
            prices: 價格列表

        Returns:
            IndicatorResult: 所有指標結果
        """
        params = INDICATOR_PARAMS

        result = IndicatorResult(
            symbol=symbol,
            current_price=prices[-1] if prices else 0
        )

        # 移動平均線
        result.sma_short = self.calculate_sma(prices, params["sma_short"])
        result.sma_long = self.calculate_sma(prices, params["sma_long"])
        result.ema_short = self.calculate_ema(prices, params["sma_short"])
        result.ema_long = self.calculate_ema(prices, params["sma_long"])

        # RSI
        result.rsi = self.calculate_rsi(prices, params["rsi_period"])

        # MACD
        result.macd, result.macd_signal, result.macd_histogram = self.calculate_macd(
            prices,
            params["macd_fast"],
            params["macd_slow"],
            params["macd_signal"]
        )

        # 布林帶
        result.bollinger_upper, _, result.bollinger_lower = self.calculate_bollinger_bands(prices)

        # 趨勢和信號
        result.trend = self.analyze_trend(result)
        result.signal = self.generate_signal(result)

        return result

    def format_indicators(self, result: IndicatorResult) -> str:
        """
        格式化指標結果為可讀字符串

        Args:
            result: 指標結果

        Returns:
            str: 格式化後的字符串
        """
        lines = [
            f"\n{'='*50}",
            f"技術指標分析 - {result.symbol}",
            f"{'='*50}",
            f"當前價格: ${result.current_price:,.2f}",
            "",
            "【移動平均線】",
            f"  SMA({INDICATOR_PARAMS['sma_short']}):  ${result.sma_short:,.2f}" if result.sma_short else "  SMA(短): 數據不足",
            f"  SMA({INDICATOR_PARAMS['sma_long']}): ${result.sma_long:,.2f}" if result.sma_long else "  SMA(長): 數據不足",
            f"  EMA({INDICATOR_PARAMS['sma_short']}):  ${result.ema_short:,.2f}" if result.ema_short else "  EMA(短): 數據不足",
            "",
            "【動量指標】",
            f"  RSI(14): {result.rsi:.2f}" if result.rsi else "  RSI: 數據不足",
            f"    {'⚠️ 超買區域 (>' + str(70) + ')' if result.rsi and result.rsi > 70 else '⚠️ 超賣區域 (<30)' if result.rsi and result.rsi < 30 else '✓ 正常區間'}",
            "",
            "【MACD】",
            f"  MACD: {result.macd:.4f}" if result.macd else "  MACD: 數據不足",
            f"  Signal: {result.macd_signal:.4f}" if result.macd_signal else "",
            f"  Histogram: {result.macd_histogram:.4f}" if result.macd_histogram else "",
            f"    {'📈 看漲 (MACD > Signal)' if result.macd_histogram and result.macd_histogram > 0 else '📉 看跌 (MACD < Signal)'}",
            "",
            "【布林帶】",
            f"  上軌: ${result.bollinger_upper:,.2f}" if result.bollinger_upper else "  上軌: 數據不足",
            f"  下軌: ${result.bollinger_lower:,.2f}" if result.bollinger_lower else "  下軌: 數據不足",
            "",
            "【綜合分析】",
            f"  趨勢: {'🟢 看漲 (Bullish)' if result.trend == 'bullish' else '🔴 看跌 (Bearish)' if result.trend == 'bearish' else '⚪ 中性 (Neutral)'}",
            f"  信號: {'🟢 買入 (BUY)' if result.signal == 'buy' else '🔴 賣出 (SELL)' if result.signal == 'sell' else '⚪ 持有 (HOLD)'}",
            f"{'='*50}"
        ]

        return "\n".join(lines)


if __name__ == "__main__":
    # 測試技術指標計算
    print("測試技術指標模組")

    # 模擬價格數據 (30天)
    test_prices = [
        45000, 45200, 44800, 46000, 46500,
        47000, 46800, 47500, 48000, 47800,
        48500, 49000, 48800, 49500, 50000,
        49800, 50500, 51000, 50800, 51500,
        52000, 51800, 52500, 53000, 52800,
        53500, 54000, 53800, 54500, 55000
    ]

    calculator = TechnicalIndicators()
    result = calculator.calculate_all("BTC", test_prices)
    print(calculator.format_indicators(result))
