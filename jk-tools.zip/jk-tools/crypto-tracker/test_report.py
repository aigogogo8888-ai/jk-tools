"""
測試報告發送 - 立即執行並發送加密貨幣追蹤報告到飛書
"""

import subprocess
import sys

def run_tracker():
    """運行追蹤系統並獲取報告"""
    result = subprocess.run(
        [sys.executable, "main.py", "--report"],
        capture_output=True,
        text=True,
        encoding='utf-8'
    )
    return result.stdout

if __name__ == "__main__":
    print("🚀 正在生成加密貨幣追蹤報告...")
    print("=" * 60)

    report = run_tracker()

    # 輸出報告內容
    print(report)

    print("\n" + "=" * 60)
    print("✅ 報告生成完成！")
    print("=" * 60)
    print("\n此報告將在每天早上 9:00 自動發送到飛書")
    print("定時任務 ID: 7f1e2758-8bba-4349-84c8-6aca3b87cfef")
