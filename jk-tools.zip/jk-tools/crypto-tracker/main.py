"""
比特幣追蹤系統 - 主程式入口

功能：
1. 獲取即時加密貨幣價格
2. 計算技術指標 (MA, RSI, MACD, Bollinger Bands)
3. 監控價格異動並生成警報
4. 生成分析報告

使用方法：
    python main.py [options]

選項：
    --symbol    指定幣種 (默認: 全部)
    --indicator 只顯示技術指標
    --alert     只檢查價格警報
    --report    生成完整報告
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import argparse
from typing import List, Optional
from data_fetcher import CryptoDataFetcher
from indicators import TechnicalIndicators
from alert_system import AlertSystem
from config import CRYPTO_SYMBOLS


class CryptoTracker:
    """加密貨幣追蹤器主類"""

    def __init__(self):
        self.fetcher = CryptoDataFetcher()
        self.indicators = TechnicalIndicators()
        self.alert_system = AlertSystem()

    def get_market_overview(self) -> str:
        """獲取市場整體概覽"""
        overview = self.fetcher.get_market_overview()

        if not overview:
            return "無法獲取市場概覽數據"

        lines = [
            "\n" + "=" * 60,
            "📊 加密貨幣市場概覽",
            "=" * 60,
            f"總市值: ${overview.get('total_market_cap_usd', 0):,.0f}",
            f"24h 總交易量: ${overview.get('total_volume_24h_usd', 0):,.0f}",
            f"24h 市值變化: {overview.get('market_cap_change_24h', 0):+.2f}%",
            f"活躍幣種數: {overview.get('active_cryptocurrencies', 0):,}",
            "",
            "【市場主導率】",
            f"  BTC: {overview.get('btc_dominance', 0):.2f}%",
            f"  ETH: {overview.get('eth_dominance', 0):.2f}%",
            "=" * 60
        ]

        return "\n".join(lines)

    def get_price_table(self) -> str:
        """獲取價格表格"""
        prices = self.fetcher.get_current_prices()

        if not prices:
            return "無法獲取價格數據"

        lines = [
            "\n" + "=" * 70,
            "💰 即時價格行情",
            "=" * 70,
            f"{'幣種':<8} {'價格 (USD)':>15} {'24h 變化':>12} {'市值':>18} {'24h 交易量':>18}",
            "-" * 70
        ]

        for symbol, data in prices.items():
            price = data['price']
            change = data['change_24h']
            market_cap = data['market_cap']
            volume = data['volume_24h']

            change_str = f"{change:+.2f}%"
            change_icon = "🟢" if change > 0 else "🔴" if change < 0 else "⚪"

            lines.append(
                f"{symbol:<8} ${price:>14,.2f} {change_icon} {change_str:>8} "
                f"${market_cap:>15,.0f} ${volume:>15,.0f}"
            )

        lines.append("=" * 70)
        return "\n".join(lines)

    def analyze_symbol(self, symbol: str, coin_id: str) -> str:
        """
        分析單個幣種

        Args:
            symbol: 幣種代碼
            coin_id: CoinGecko ID

        Returns:
            str: 分析結果
        """
        lines = []

        # 1. 獲取詳細資訊
        info = self.fetcher.get_coin_info(coin_id)
        if info:
            lines.extend([
                f"\n{'='*60}",
                f"🔍 {info.get('name', symbol)} ({symbol}) 詳細分析",
                f"{'='*60}",
                f"當前價格: ${info.get('current_price', 0):,.2f}",
                f"24h 最高: ${info.get('high_24h', 0):,.2f}",
                f"24h 最低: ${info.get('low_24h', 0):,.2f}",
                "",
                "【價格變化】",
                f"  24h: {info.get('price_change_24h_percent', 0):+.2f}%",
                f"  7d:  {info.get('price_change_7d_percent', 0):+.2f}%",
                f"  30d: {info.get('price_change_30d_percent', 0):+.2f}%",
                "",
                "【歷史價格】",
                f"  歷史最高 (ATH): ${info.get('ath', 0):,.2f} ({info.get('ath_change_percent', 0):+.2f}%)",
                f"  歷史最低 (ATL): ${info.get('atl', 0):,.2f}",
                "",
                "【市場數據】",
                f"  市值: ${info.get('market_cap', 0):,.0f}",
                f"  24h 交易量: ${info.get('total_volume', 0):,.0f}",
                f"  流通供應量: {info.get('circulating_supply', 0):,.0f}",
            ])

        # 2. 獲取歷史價格並計算技術指標
        historical = self.fetcher.get_historical_prices(coin_id, days=30)
        if historical and len(historical) >= 14:
            prices = [h['price'] for h in historical]
            indicator_result = self.indicators.calculate_all(symbol, prices)
            lines.append(self.indicators.format_indicators(indicator_result))

            # 3. 檢查價格警報
            current_price = info.get('current_price', prices[-1] if prices else 0)
            current_data = {
                'price': current_price,
                'change_24h': info.get('price_change_24h_percent', 0)
            }

            alerts = self.alert_system.check_price_change_alerts(symbol, current_data)
            for alert in alerts:
                self.alert_system.add_alert(alert)

            if alerts:
                lines.append("\n【觸發的警報】")
                for alert in alerts:
                    lines.append(self.alert_system.format_alert(alert))

        return "\n".join(lines)

    def generate_full_report(self, symbols: Optional[List[str]] = None) -> str:
        """
        生成完整報告

        Args:
            symbols: 指定幣種列表，None 表示全部

        Returns:
            str: 完整報告
        """
        lines = []

        # 1. 市場概覽
        lines.append(self.get_market_overview())

        # 2. 價格表格
        lines.append(self.get_price_table())

        # 3. 各幣種詳細分析
        target_symbols = symbols if symbols else list(CRYPTO_SYMBOLS.values())

        for coin_id, symbol in CRYPTO_SYMBOLS.items():
            if symbol in target_symbols:
                lines.append(self.analyze_symbol(symbol, coin_id))

        # 4. 警報摘要
        lines.append("\n" + self.alert_system.generate_alert_summary())

        # 保存警報
        self.alert_system.save_alerts()

        return "\n".join(lines)

    def run(self, args: argparse.Namespace):
        """運行主程式"""
        print("\n" + "=" * 60)
        print("🚀 比特幣追蹤系統啟動")
        print("=" * 60)

        if args.report or (not args.indicator and not args.alert):
            # 生成完整報告
            symbols = [args.symbol.upper()] if args.symbol else None
            report = self.generate_full_report(symbols)
            print(report)

        elif args.indicator:
            # 只顯示技術指標
            symbol = args.symbol.upper() if args.symbol else "BTC"
            coin_id = None
            for cid, sym in CRYPTO_SYMBOLS.items():
                if sym == symbol:
                    coin_id = cid
                    break

            if coin_id:
                print(self.analyze_symbol(symbol, coin_id))
            else:
                print(f"不支援的幣種: {symbol}")

        elif args.alert:
            # 只檢查警報
            prices = self.fetcher.get_current_prices()
            for symbol, data in prices.items():
                alerts = self.alert_system.check_price_change_alerts(symbol, data)
                for alert in alerts:
                    self.alert_system.add_alert(alert)

            print(self.alert_system.generate_alert_summary())
            self.alert_system.save_alerts()

        print("\n✅ 分析完成")


def main():
    """主函數"""
    parser = argparse.ArgumentParser(
        description="比特幣追蹤系統 - 加密貨幣市場分析工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python main.py                    # 生成完整報告
  python main.py --symbol BTC       # 只分析比特幣
  python main.py --indicator        # 只顯示技術指標
  python main.py --alert            # 只檢查價格警報
  python main.py --report           # 生成完整報告
        """
    )

    parser.add_argument(
        "--symbol",
        type=str,
        help="指定幣種代碼 (例如: BTC, ETH, SOL)"
    )

    parser.add_argument(
        "--indicator",
        action="store_true",
        help="只顯示技術指標分析"
    )

    parser.add_argument(
        "--alert",
        action="store_true",
        help="只檢查價格異動警報"
    )

    parser.add_argument(
        "--report",
        action="store_true",
        help="生成完整分析報告"
    )

    args = parser.parse_args()

    # 創建追蹤器並運行
    tracker = CryptoTracker()
    tracker.run(args)


if __name__ == "__main__":
    main()
