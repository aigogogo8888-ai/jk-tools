"""
投資賺錢計畫排程工具

功能：
1. 創建投資相關的定期行程
2. 設定市場分析、研究時間
3. 整合到 Google Calendar
4. 生成投資計畫行事曆

使用方法：
    python investment_schedule.py [options]
"""

import os
import sys
import csv
from datetime import datetime, timedelta
from typing import List, Dict


class InvestmentScheduleGenerator:
    """投資計畫行程生成器"""

    def __init__(self):
        self.events = []
        self.timezone = "Asia/Taipei"

    def create_daily_routine(self, start_date: str, days: int = 30):
        """
        創建每日投資例行行程

        Args:
            start_date: 開始日期 (YYYY-MM-DD)
            days: 天數
        """
        start = datetime.strptime(start_date, "%Y-%m-%d")

        for i in range(days):
            current_date = start + timedelta(days=i)
            date_str = current_date.strftime("%Y-%m-%d")

            # 早上：市場回顧
            self.events.append({
                'title': '📊 加密貨幣市場回顧',
                'start_date': date_str,
                'start_time': '09:00',
                'end_date': date_str,
                'end_time': '09:30',
                'location': '電腦前',
                'description': '查看比特幣追蹤系統報告，檢查價格變化和警報'
            })

            # 晚上：投資研究
            self.events.append({
                'title': '📈 投資研究時間',
                'start_date': date_str,
                'start_time': '20:00',
                'end_date': date_str,
                'end_time': '21:00',
                'location': '書房',
                'description': '技術分析、市場研究、策略回顧'
            })

    def create_weekly_review(self, start_date: str, weeks: int = 4):
        """
        創建每週回顧行程

        Args:
            start_date: 開始日期
            weeks: 週數
        """
        start = datetime.strptime(start_date, "%Y-%m-%d")

        # 找到第一個週日
        while start.weekday() != 6:  # 6 = Sunday
            start += timedelta(days=1)

        for i in range(weeks):
            current_date = start + timedelta(weeks=i)
            date_str = current_date.strftime("%Y-%m-%d")

            self.events.append({
                'title': '📋 本週投資回顧',
                'start_date': date_str,
                'start_time': '15:00',
                'end_date': date_str,
                'end_time': '17:00',
                'location': '書房',
                'description': '本週投資表現總結、策略調整、下週計畫'
            })

    def create_monthly_planning(self, start_date: str, months: int = 3):
        """
        創建每月計畫行程

        Args:
            start_date: 開始日期
            months: 月數
        """
        start = datetime.strptime(start_date, "%Y-%m-%d")

        for i in range(months):
            # 每月第一天
            if i == 0:
                current = start.replace(day=1)
            else:
                # 下個月第一天
                if start.month + i > 12:
                    current = start.replace(year=start.year + 1, month=(start.month + i) % 12, day=1)
                else:
                    current = start.replace(month=start.month + i, day=1)

            date_str = current.strftime("%Y-%m-%d")

            self.events.append({
                'title': '🎯 月度投資計畫',
                'start_date': date_str,
                'start_time': '10:00',
                'end_date': date_str,
                'end_time': '12:00',
                'location': '書房',
                'description': '設定本月投資目標、資產配置檢視、風險評估'
            })

    def create_special_events(self):
        """創建特殊投資相關行程"""
        special_events = [
            {
                'title': '💰 季度投資組合再平衡',
                'start_date': '2026-03-31',
                'start_time': '14:00',
                'end_date': '2026-03-31',
                'end_time': '16:00',
                'location': '線上',
                'description': '檢視投資組合表現，調整資產配置比例'
            },
            {
                'title': '📚 投資書籍閱讀時間',
                'start_date': '2026-03-15',
                'start_time': '19:00',
                'end_date': '2026-03-15',
                'end_time': '21:00',
                'location': '書房',
                'description': '閱讀投資相關書籍，提升投資知識'
            },
            {
                'title': '🎓 線上投資課程',
                'start_date': '2026-03-20',
                'start_time': '19:30',
                'end_date': '2026-03-20',
                'end_time': '21:30',
                'location': '線上',
                'description': '學習新的投資策略和技術分析方法'
            },
            {
                'title': '📉 市場大跌檢討會',
                'start_date': '2026-03-25',
                'start_time': '20:00',
                'end_date': '2026-03-25',
                'end_time': '21:00',
                'location': '書房',
                'description': '分析市場下跌原因，檢討應對策略'
            },
        ]

        self.events.extend(special_events)

    def export_to_csv(self, filepath: str = "investment_schedule.csv"):
        """
        導出為 CSV 檔案

        Args:
            filepath: 輸出檔案路徑
        """
        with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.writer(f)
            writer.writerow(['title', 'start_date', 'start_time', 'end_date', 'end_time', 'location', 'description'])

            for event in self.events:
                writer.writerow([
                    event['title'],
                    event['start_date'],
                    event['start_time'],
                    event['end_date'],
                    event['end_time'],
                    event['location'],
                    event['description']
                ])

        print(f"✅ 投資計畫行程已導出: {filepath}")
        print(f"   總計: {len(self.events)} 個事件")

    def print_summary(self):
        """打印行程摘要"""
        print("\n" + "=" * 60)
        print("💰 投資賺錢計畫行程表")
        print("=" * 60)

        # 按日期分組
        by_date = {}
        for event in self.events:
            date = event['start_date']
            if date not in by_date:
                by_date[date] = []
            by_date[date].append(event)

        # 排序日期
        sorted_dates = sorted(by_date.keys())

        for date in sorted_dates[:10]:  # 只顯示前 10 天
            print(f"\n📅 {date}")
            for event in sorted(by_date[date], key=lambda x: x['start_time']):
                print(f"   {event['start_time']}-{event['end_time']} {event['title']}")
                if event['location']:
                    print(f"   📍 {event['location']}")

        if len(sorted_dates) > 10:
            print(f"\n... 還有 {len(sorted_dates) - 10} 天的行程")

        print(f"\n{'='*60}")
        print(f"總計: {len(self.events)} 個事件")
        print(f"{'='*60}")


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="投資賺錢計畫排程工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 生成完整投資計畫 (30天)
  python investment_schedule.py --days 30 --weeks 4 --months 3

  # 只生成每日例行
  python investment_schedule.py --days 30

  # 生成並導出 CSV
  python investment_schedule.py --days 30 --export
        """
    )

    parser.add_argument(
        "--start-date",
        default=datetime.now().strftime("%Y-%m-%d"),
        help="開始日期 (YYYY-MM-DD，預設: 今天)"
    )

    parser.add_argument(
        "--days",
        type=int,
        default=30,
        help="生成幾天的每日行程 (預設: 30)"
    )

    parser.add_argument(
        "--weeks",
        type=int,
        default=4,
        help="生成幾週的週回顧 (預設: 4)"
    )

    parser.add_argument(
        "--months",
        type=int,
        default=3,
        help="生成幾個月的月計畫 (預設: 3)"
    )

    parser.add_argument(
        "--export",
        action="store_true",
        help="導出為 CSV 檔案"
    )

    parser.add_argument(
        "--output",
        default="investment_schedule.csv",
        help="輸出檔案名稱 (預設: investment_schedule.csv)"
    )

    args = parser.parse_args()

    # 創建生成器
    generator = InvestmentScheduleGenerator()

    print("💰 正在生成投資賺錢計畫行程...")
    print(f"   開始日期: {args.start_date}")

    # 生成各類行程
    if args.days > 0:
        print(f"   生成 {args.days} 天的每日例行...")
        generator.create_daily_routine(args.start_date, args.days)

    if args.weeks > 0:
        print(f"   生成 {args.weeks} 週的週回顧...")
        generator.create_weekly_review(args.start_date, args.weeks)

    if args.months > 0:
        print(f"   生成 {args.months} 個月的月計畫...")
        generator.create_monthly_planning(args.start_date, args.months)

    print("   生成特殊事件...")
    generator.create_special_events()

    # 顯示摘要
    generator.print_summary()

    # 導出 CSV
    if args.export:
        generator.export_to_csv(args.output)

        print("\n" + "=" * 60)
        print("📖 下一步:")
        print("=" * 60)
        print("1. 使用 Google Calendar 導入工具:")
        print(f"   python google_calendar_import.py {args.output}")
        print("\n2. 或直接導入到 Outlook:")
        print(f"   使用 calendar-tools 中的工具")


if __name__ == "__main__":
    main()
