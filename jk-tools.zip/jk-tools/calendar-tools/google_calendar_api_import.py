"""
Google Calendar API 直接導入工具

需要先設定 Google Cloud Console:
1. 啟用 Google Calendar API
2. 建立 OAuth 2.0 憑證
3. 下載 credentials.json 放到此目錄

安裝依賴:
    pip install google-auth-oauthlib google-auth-httplib2 google-api-python-client

使用方法:
    python google_calendar_api_import.py <csv_file>
"""

import os
import sys
import csv
import pickle
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Google Calendar API 權限範圍
SCOPES = ['https://www.googleapis.com/auth/calendar']


def get_credentials():
    """取得或創建 Google API 憑證"""
    creds = None

    # 檢查是否有已儲存的 token
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    # 如果沒有憑證或已過期，則重新授權
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not os.path.exists('credentials.json'):
                print("❌ 找不到 credentials.json")
                print("請按照以下步驟設定:")
                print("1. 前往 https://console.cloud.google.com/")
                print("2. 建立新專案或選擇現有專案")
                print("3. 啟用 Google Calendar API")
                print("4. 建立 OAuth 2.0 憑證 (桌面應用程式)")
                print("5. 下載 credentials.json 放到此目錄")
                sys.exit(1)

            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)

        # 儲存憑證供下次使用
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    return creds


def create_event(service, calendar_id, event_data):
    """
    創建行事曆事件

    Args:
        service: Google Calendar API 服務
        calendar_id: 行事曆 ID
        event_data: 事件數據字典

    Returns:
        創建的事件對象
    """
    event = {
        'summary': event_data['title'],
        'location': event_data.get('location', ''),
        'description': event_data.get('description', ''),
        'start': {
            'dateTime': event_data['start_datetime'],
            'timeZone': event_data.get('timezone', 'Asia/Taipei'),
        },
        'end': {
            'dateTime': event_data['end_datetime'],
            'timeZone': event_data.get('timezone', 'Asia/Taipei'),
        },
        'reminders': {
            'useDefault': False,
            'overrides': [
                {'method': 'popup', 'minutes': 10},
                {'method': 'email', 'minutes': 60},
            ],
        },
    }

    try:
        event = service.events().insert(calendarId=calendar_id, body=event).execute()
        return event
    except HttpError as e:
        print(f"❌ 創建事件失敗: {e}")
        return None


def parse_csv(filepath):
    """解析 CSV 檔案"""
    events = []

    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)

        for row in reader:
            try:
                title = row.get('title') or row.get('標題') or row.get('subject') or ''
                location = row.get('location') or row.get('地點') or ''
                description = row.get('description') or row.get('描述') or ''

                start_date = row.get('start_date') or row.get('開始日期') or row.get('date') or ''
                start_time = row.get('start_time') or row.get('開始時間') or row.get('time') or '00:00'
                end_date = row.get('end_date') or row.get('結束日期') or start_date
                end_time = row.get('end_time') or row.get('結束時間') or ''

                # 如果沒有結束時間，預設 1 小時後
                if not end_time:
                    from datetime import datetime as dt, timedelta
                    start_dt = dt.strptime(f"{start_date} {start_time}", "%Y-%m-%d %H:%M")
                    end_dt = start_dt + timedelta(hours=1)
                    end_date = end_dt.strftime("%Y-%m-%d")
                    end_time = end_dt.strftime("%H:%M")

                start_datetime = f"{start_date}T{start_time}:00+08:00"
                end_datetime = f"{end_date}T{end_time}:00+08:00"

                events.append({
                    'title': title,
                    'start_datetime': start_datetime,
                    'end_datetime': end_datetime,
                    'location': location,
                    'description': description,
                    'timezone': 'Asia/Taipei'
                })

            except Exception as e:
                print(f"解析行失敗: {row}, 錯誤: {e}")
                continue

    return events


def main():
    if len(sys.argv) < 2:
        print("使用方法: python google_calendar_api_import.py <csv_file>")
        sys.exit(1)

    csv_file = sys.argv[1]

    if not os.path.exists(csv_file):
        print(f"❌ 找不到檔案: {csv_file}")
        sys.exit(1)

    print("📂 正在讀取行程資料...")
    events = parse_csv(csv_file)
    print(f"✅ 讀取到 {len(events)} 個事件\n")

    print("🔐 正在連接 Google Calendar API...")
    creds = get_credentials()
    service = build('calendar', 'v3', credentials=creds)

    # 獲取主要行事曆 ID
    calendar_id = 'primary'

    print(f"📅 開始導入到 Google Calendar...\n")

    success_count = 0
    for i, event_data in enumerate(events, 1):
        print(f"[{i}/{len(events)}] 創建: {event_data['title']}")
        event = create_event(service, calendar_id, event_data)
        if event:
            print(f"   ✅ 成功: {event.get('htmlLink')}")
            success_count += 1

    print(f"\n{'='*60}")
    print(f"✅ 導入完成: {success_count}/{len(events)} 個事件成功")
    print(f"{'='*60}")


if __name__ == '__main__':
    main()
