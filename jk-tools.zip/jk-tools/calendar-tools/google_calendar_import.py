"""
Google 行事曆快速導入工具

功能：
1. 從 CSV/Excel 檔案讀取行程資料
2. 一鍵導入到 Google Calendar
3. 支援批量創建、更新、刪除事件
4. 自動處理時區和重複事件

使用方法：
    python google_calendar_import.py <csv_file> [options]

CSV 格式要求：
    title, start_date, start_time, end_date, end_time, location, description
    例：會議, 2026-03-15, 09:00, 2026-03-15, 10:00, 會議室A, 週報討論
"""

import os
import sys
import csv
import json
import argparse
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from dataclasses import dataclass


@dataclass
class CalendarEvent:
    """行事曆事件數據類"""
    title: str
    start_datetime: str  # ISO 8601 format
    end_datetime: str
    location: str = ""
    description: str = ""
    timezone: str = "Asia/Taipei"
    reminders: List[Dict] = None


class GoogleCalendarImporter:
    """Google 行事曆導入器"""

    def __init__(self):
        self.events: List[CalendarEvent] = []
        self.timezone = "Asia/Taipei"

    def parse_csv(self, filepath: str) -> List[CalendarEvent]:
        """
        解析 CSV 檔案

        Args:
            filepath: CSV 檔案路徑

        Returns:
            List[CalendarEvent]: 事件列表
        """
        events = []

        with open(filepath, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)

            for row in reader:
                try:
                    # 支援多種欄位名稱格式
                    title = row.get('title') or row.get('標題') or row.get('subject') or row.get('主題') or ''
                    location = row.get('location') or row.get('地點') or row.get('place') or ''
                    description = row.get('description') or row.get('描述') or row.get('備註') or row.get('note') or ''

                    # 日期時間解析
                    start_date = row.get('start_date') or row.get('開始日期') or row.get('date') or row.get('日期') or ''
                    start_time = row.get('start_time') or row.get('開始時間') or row.get('time') or row.get('時間') or '00:00'
                    end_date = row.get('end_date') or row.get('結束日期') or start_date
                    end_time = row.get('end_time') or row.get('結束時間') or ''

                    # 如果沒有結束時間，預設 1 小時後
                    if not end_time:
                        start_dt = datetime.strptime(f"{start_date} {start_time}", "%Y-%m-%d %H:%M")
                        end_dt = start_dt + timedelta(hours=1)
                        end_date = end_dt.strftime("%Y-%m-%d")
                        end_time = end_dt.strftime("%H:%M")

                    # 組合日期時間
                    start_datetime = f"{start_date}T{start_time}:00"
                    end_datetime = f"{end_date}T{end_time}:00"

                    event = CalendarEvent(
                        title=title,
                        start_datetime=start_datetime,
                        end_datetime=end_datetime,
                        location=location,
                        description=description,
                        timezone=self.timezone
                    )

                    events.append(event)

                except Exception as e:
                    print(f"解析行失敗: {row}, 錯誤: {e}")
                    continue

        self.events = events
        return events

    def parse_excel(self, filepath: str) -> List[CalendarEvent]:
        """
        解析 Excel 檔案 (需要安裝 openpyxl)

        Args:
            filepath: Excel 檔案路徑

        Returns:
            List[CalendarEvent]: 事件列表
        """
        try:
            import openpyxl
        except ImportError:
            print("請先安裝 openpyxl: pip install openpyxl")
            return []

        events = []
        wb = openpyxl.load_workbook(filepath)
        ws = wb.active

        # 獲取標題行
        headers = [cell.value for cell in ws[1]]

        for row in ws.iter_rows(min_row=2, values_only=True):
            try:
                row_dict = dict(zip(headers, row))

                title = row_dict.get('title') or row_dict.get('標題') or row_dict.get('subject') or ''
                location = row_dict.get('location') or row_dict.get('地點') or ''
                description = row_dict.get('description') or row_dict.get('描述') or ''

                start_date = row_dict.get('start_date') or row_dict.get('開始日期') or row_dict.get('date') or ''
                start_time = row_dict.get('start_time') or row_dict.get('開始時間') or row_dict.get('time') or '00:00'
                end_date = row_dict.get('end_date') or row_dict.get('結束日期') or start_date
                end_time = row_dict.get('end_time') or row_dict.get('結束時間') or ''

                # 處理時間格式
                if isinstance(start_time, datetime):
                    start_time = start_time.strftime("%H:%M")
                if isinstance(end_time, datetime):
                    end_time = end_time.strftime("%H:%M")
                if isinstance(start_date, datetime):
                    start_date = start_date.strftime("%Y-%m-%d")
                if isinstance(end_date, datetime):
                    end_date = end_date.strftime("%Y-%m-%d")

                if not end_time:
                    start_dt = datetime.strptime(f"{start_date} {start_time}", "%Y-%m-%d %H:%M")
                    end_dt = start_dt + timedelta(hours=1)
                    end_date = end_dt.strftime("%Y-%m-%d")
                    end_time = end_dt.strftime("%H:%M")

                start_datetime = f"{start_date}T{start_time}:00"
                end_datetime = f"{end_date}T{end_time}:00"

                event = CalendarEvent(
                    title=title,
                    start_datetime=start_datetime,
                    end_datetime=end_datetime,
                    location=location,
                    description=description,
                    timezone=self.timezone
                )

                events.append(event)

            except Exception as e:
                print(f"解析行失敗: {row}, 錯誤: {e}")
                continue

        self.events = events
        return events

    def generate_ics(self, output_path: str = "calendar_export.ics"):
        """
        生成 ICS 檔案 (可以導入 Google Calendar)

        Args:
            output_path: 輸出檔案路徑
        """
        ics_lines = [
            "BEGIN:VCALENDAR",
            "VERSION:2.0",
            "PRODID:-//Crypto Tracker//Calendar Import//EN",
            "CALSCALE:GREGORIAN",
            "METHOD:PUBLISH",
            f"X-WR-TIMEZONE:{self.timezone}",
        ]

        for event in self.events:
            uid = f"{datetime.now().strftime('%Y%m%dT%H%M%S')}-{hash(event.title)}@cryptotracker"

            ics_lines.extend([
                "BEGIN:VEVENT",
                f"UID:{uid}",
                f"DTSTART;TZID={self.timezone}:{event.start_datetime.replace('-', '').replace(':', '')}",
                f"DTEND;TZID={self.timezone}:{event.end_datetime.replace('-', '').replace(':', '')}",
                f"SUMMARY:{event.title}",
            ])

            if event.location:
                ics_lines.append(f"LOCATION:{event.location}")
            if event.description:
                ics_lines.append(f"DESCRIPTION:{event.description}")

            ics_lines.extend([
                "END:VEVENT",
            ])

        ics_lines.append("END:VCALENDAR")

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("\r\n".join(ics_lines))

        print(f"✅ ICS 檔案已生成: {output_path}")
        print(f"   包含 {len(self.events)} 個事件")

    def print_summary(self):
        """打印事件摘要"""
        print("\n" + "=" * 60)
        print("📅 行程摘要")
        print("=" * 60)
        print(f"總計: {len(self.events)} 個事件\n")

        for i, event in enumerate(self.events[:10], 1):  # 只顯示前 10 個
            print(f"{i}. {event.title}")
            print(f"   時間: {event.start_datetime} ~ {event.end_datetime}")
            if event.location:
                print(f"   地點: {event.location}")
            print()

        if len(self.events) > 10:
            print(f"... 還有 {len(self.events) - 10} 個事件")

    def generate_google_calendar_url(self, event: CalendarEvent) -> str:
        """
        生成 Google Calendar 快速添加 URL

        Args:
            event: 事件對象

        Returns:
            str: Google Calendar URL
        """
        base_url = "https://calendar.google.com/calendar/render"

        # 格式化時間
        start = event.start_datetime.replace("-", "").replace(":", "")
        end = event.end_datetime.replace("-", "").replace(":", "")

        params = {
            "action": "TEMPLATE",
            "text": event.title,
            "dates": f"{start}/{end}",
            "ctz": self.timezone,
        }

        if event.location:
            params["location"] = event.location
        if event.description:
            params["details"] = event.description

        # 構建 URL
        param_str = "&".join([f"{k}={requests.utils.quote(str(v))}" for k, v in params.items()])
        return f"{base_url}?{param_str}"

    def generate_import_guide(self):
        """生成導入指南"""
        guide = """
╔══════════════════════════════════════════════════════════════════╗
║              Google 行事曆導入指南                                ║
╚══════════════════════════════════════════════════════════════════╝

方法一：使用 ICS 檔案導入 (推薦)
─────────────────────────────────
1. 打開 Google Calendar (calendar.google.com)
2. 點擊右上角「設定」⚙️
3. 選擇「設定」
4. 左側選單選擇「匯入與匯出」
5. 點擊「選取電腦中的檔案」，選擇生成的 .ics 檔案
6. 選擇要導入的行事曆
7. 點擊「匯入」

方法二：使用 Google Calendar API (進階)
─────────────────────────────────────────
1. 啟用 Google Calendar API:
   https://console.cloud.google.com/apis/library/calendar-json.googleapis.com

2. 建立 OAuth 2.0 憑證:
   https://console.cloud.google.com/apis/credentials

3. 下載 credentials.json 放到專案目錄

4. 安裝 Google API 套件:
   pip install google-auth-oauthlib google-auth-httplib2 google-api-python-client

5. 執行授權並導入:
   python google_calendar_api_import.py

方法三：手動快速添加
────────────────────
每個事件都可以使用以下 URL 快速添加到 Google Calendar:
"""
        print(guide)

        if self.events:
            print("\n示例 URL (第一個事件):")
            try:
                import requests
                url = self.generate_google_calendar_url(self.events[0])
                print(f"{url}\n")
            except ImportError:
                print("(需要安裝 requests 套件來生成 URL)\n")


def create_sample_csv(output_path: str = "sample_schedule.csv"):
    """創建範例 CSV 檔案"""
    sample_data = [
        ["title", "start_date", "start_time", "end_date", "end_time", "location", "description"],
        ["早會", "2026-03-15", "09:00", "2026-03-15", "10:00", "會議室A", "每日站會"],
        ["客戶會議", "2026-03-15", "14:00", "2026-03-15", "15:30", "線上 Zoom", "專案進度報告"],
        ["健身房", "2026-03-16", "18:00", "2026-03-16", "19:30", "健身中心", "重訓日"],
        ["投資研究時間", "2026-03-17", "20:00", "2026-03-17", "21:00", "書房", "比特幣技術分析"],
        ["週末出遊", "2026-03-21", "08:00", "2026-03-21", "18:00", "陽明山", "賞花一日遊"],
    ]

    with open(output_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerows(sample_data)

    print(f"✅ 範例 CSV 已創建: {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Google 行事曆快速導入工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 導入 CSV 並生成 ICS
  python google_calendar_import.py schedule.csv

  # 導入 Excel
  python google_calendar_import.py schedule.xlsx --format excel

  # 創建範例 CSV
  python google_calendar_import.py --sample

  # 只顯示摘要不生成檔案
  python google_calendar_import.py schedule.csv --preview
        """
    )

    parser.add_argument(
        "input_file",
        nargs="?",
        help="輸入檔案 (CSV 或 Excel)"
    )

    parser.add_argument(
        "--format",
        choices=["csv", "excel", "auto"],
        default="auto",
        help="輸入檔案格式 (預設: 自動偵測)"
    )

    parser.add_argument(
        "--output",
        default="calendar_export.ics",
        help="輸出 ICS 檔案路徑 (預設: calendar_export.ics)"
    )

    parser.add_argument(
        "--preview",
        action="store_true",
        help="只顯示預覽，不生成檔案"
    )

    parser.add_argument(
        "--sample",
        action="store_true",
        help="創建範例 CSV 檔案"
    )

    parser.add_argument(
        "--guide",
        action="store_true",
        help="顯示 Google Calendar 導入指南"
    )

    args = parser.parse_args()

    if args.sample:
        create_sample_csv()
        return

    if args.guide:
        importer = GoogleCalendarImporter()
        importer.generate_import_guide()
        return

    if not args.input_file:
        parser.print_help()
        return

    # 創建導入器
    importer = GoogleCalendarImporter()

    # 偵測檔案格式
    file_format = args.format
    if file_format == "auto":
        if args.input_file.endswith('.xlsx') or args.input_file.endswith('.xls'):
            file_format = "excel"
        else:
            file_format = "csv"

    # 解析檔案
    print(f"📂 正在讀取: {args.input_file}")

    if file_format == "excel":
        importer.parse_excel(args.input_file)
    else:
        importer.parse_csv(args.input_file)

    # 顯示摘要
    importer.print_summary()

    # 生成 ICS 或顯示指南
    if not args.preview:
        importer.generate_ics(args.output)
        print("\n" + "=" * 60)
        print("📖 導入指南:")
        print("=" * 60)
        importer.generate_import_guide()


if __name__ == "__main__":
    main()
